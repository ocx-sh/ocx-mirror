def greet():
    return 'hello from purelib_pkg'
