class Class:
    @staticmethod
    def method():
        return 'dotted-attr entrypoint'


def main():
    print('console_pkg main')
