from cext_pkg._native import compute
