from abi3_pkg._native import compute
