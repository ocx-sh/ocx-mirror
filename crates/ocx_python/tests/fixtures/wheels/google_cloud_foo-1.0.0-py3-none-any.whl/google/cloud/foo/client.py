def client():
    return 'foo client'
