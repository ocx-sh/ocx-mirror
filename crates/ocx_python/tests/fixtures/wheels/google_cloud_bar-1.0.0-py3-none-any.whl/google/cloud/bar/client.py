def client():
    return 'bar client'
